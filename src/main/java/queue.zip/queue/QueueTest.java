package queue;

import org.apache.log4j.Logger;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Created by ivy on 2017/12/7.
 */
public class QueueTest {

    private static final Logger LOG = Logger.getLogger(QueueTest.class);

    public static BlockingQueue<String> queue = new ArrayBlockingQueue<String>(100);

    public static String getElement(){
        String element = null;
        try {
            element = queue.take();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return element;
    }

    public static String putElement(String str){
        try {
            queue.put(str);
        } catch (InterruptedException e) {
            LOG.error("天津元素失败",e);
        }
        return null;
    }
}
